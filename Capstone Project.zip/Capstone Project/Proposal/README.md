The required dataset called Urbansound8K can be downloaded from here: https://urbansounddataset.weebly.com/urbansound8k.html 
